解压后使用 Chrome 或 Edge 打开 foundphone-preview.html。
锁屏密码：2711。
